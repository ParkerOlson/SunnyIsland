cd $(dirname "$0")
java -jar SunnyLittleIsland.jar
